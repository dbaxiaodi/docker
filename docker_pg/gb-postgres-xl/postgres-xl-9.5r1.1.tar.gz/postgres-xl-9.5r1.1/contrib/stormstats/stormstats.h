#ifndef STORMSTATS_H
#define STORMSTATS_H

#include "postgres.h"

extern void _PG_init(void);
extern void _PG_fini(void);

#endif   /* STORMSTATS_H */
