/* contrib/stormstats/stormstats--unpackaged--1.0.sql */

ALTER EXTENSION stormstats ADD function storm_database_stats();
ALTER EXTENSION stormstats ADD view storm_database_stats;

